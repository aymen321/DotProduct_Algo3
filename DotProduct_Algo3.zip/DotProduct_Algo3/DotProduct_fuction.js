function dotproduct(a, b) {
    var n = 0,
        lim = Math.min(a.length, b.length);
    for (var i = 0; i < lim; i++) n += a[i] * b[i];
    return n;
}

assert(dotproduct([1, 2, 3, 4, 5], [6, 7, 8, 9, 10]) == 130)