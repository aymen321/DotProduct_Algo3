// Driver code

let vect_A = [3, -5, 4];
let vect_B = [2, 6, 5];
let cross_P = [];

// dotProduct function call
document.write("Dot product:");
document.write(dotProduct(vect_A, vect_B) + "<br/>");

// crossProduct function call
document.write("Cross product:");
crossProduct(vect_A, vect_B, cross_P);

// Loop that prlet
// cross product of two vector array.
for (let i = 0; i < n; i++)

    document.write(cross_P[i] + " ");

// This code is contributed by sanjoy_62.